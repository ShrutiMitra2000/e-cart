<?php
   require 'includes/common.php';
    if (!isset($_SESSION['email'])) 
    { header('location: index.php');}
    ?>
<html>
    <head>
    <title>E-CART</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
              <script src="bootstrap/js/jquery-3.5.1.min.js"></script>
              
        <!-- Latest compiled and minified JavaScript -->
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
         <?php
            include 'includes/header.php';
        ?>  
        
       <div class="container head">
       <h3> WHAT WILL BE THE PAYMENT MODE?</h3>
       <h4><a href="success.php"><button type="button" class="btn btn-primary btn-block">Cash on delivery</button></a></h4>
       <h4><a href="confirm.php"><button type="button" class="btn btn-primary btn-block">Online Payment</button></a></h4>
       </div>
        <?php
            include 'includes/footer.php';
        ?>   
    </body>
</html>
