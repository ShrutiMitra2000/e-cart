<?php
$showAlert=false;
$showError="false";
if($_SERVER["REQUEST_METHOD"]=="POST")
{
  include_once 'common.php';
  
  $email=$_POST["email"];
  $email=mysqli_real_escape_string($con,$email);

  $password=$_POST["password"];
  $password=mysqli_real_escape_string($con,$password);
  $password=md5($password);
  $exist=false;
  
    $sql="SELECT * FROM  `admin` where email='$email'";
    $result=mysqli_query($con,$sql);
    $num=mysqli_num_rows($result);
    if($num==0)
    {
      $showError="Email  doesn't exist";
      header("location:/e-cart/admin/adminlogin.php?loginsuccess=false&error=$showError");
      
    }
    else
    {$row=mysqli_fetch_assoc($result);
        $sno=$row['id'];
          $user_email=$row['email'];
          $user_pass=$row['password'];
          if($password==$user_pass)
          {
            $showAlert=true;
            
            $_SESSION['sno']=$sno;
            $_SESSION['login-email']=$user_email;
           // echo  $_SESSION['sno'];
           header("location:/e-cart/admin/adminpanel.php");
           

          }
          else
    {     $showError="Password is not matching";
        header("location:/e-cart/admin/adminlogin.php?loginsuccess=false&error=$showError");
       
        
    }
      
   
  }
}

?>
<?php
 if(isset($_GET['error']))
 { $showError=$_GET['error'];
  echo '<div class="alert alert-warning alert-dismissible fade show mb-0" role="alert">
  <strong>Error! </strong>'.$showError.'
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
 }
?>

<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <link rel="stylesheet" href="adminstyle.css">
</head>
<body>
<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->

    <!-- Icon -->
    <div class="fadeIn first">
      <img src="adminIcon.png" id="icon" alt="User Icon" height='450px' width='400px' />
    </div>

    <!-- Login Form -->
    <form method="POST" action="adminlogin.php">
                                
                                <input type="email" name="email" class="form-control"  placeholder="email"><br>
                                <input type="password" name="password" class="form-control"  placeholder="password" ><br>
                               
                           
                                
      <div class="modal-footer">
        
        <button type="submit" class="btn btn-primary">Login</button>
      </div>
      </form>
      
 

  </div>
</div>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
</body>
</html>



