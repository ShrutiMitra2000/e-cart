
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="adminstyle.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
   <style>
    #ques {
        height: 433px;
    }
    </style>
    <title>Admin Panel</title>
</head>


<body>
  <?php
  $prodid = $_GET['prodid'];
  require_once 'common.php';
  $sql = "SELECT * FROM `items` WHERE `id`=$prodid";
  $result = $con->query($sql);
  while ($row = $result->fetch_assoc()) {
    $id = $row['id'];
    $name = $row['name'];
    $price = $row['price'];
    $img = $row['image'];
  }
  require_once 'adminnav.php';
  ?>
<?php
  echo
  '<center>
    <div class="col-md-4 my-2">
     <div>
                
                <h3>Modify item</h3>
                
                <div class="card" style=" width:200px>
      <div class="card-body" style="height:500px;">
            <img class="d-block w-100" src="/e-cart/' . $img . '" height="150px" width="180px">
        <h5 class="card-title">' . $name . '</h5>
        <form action="modify.php?prodid='.$prodid.'" method="post">
                  <h6>Give New Details</h6>
                  <input type="hidden" id="productid" name="productid" value="'.$prodid.'">
                    <input type="text" placeholder=" New Price of product"  name="newprice" class="add" required>
                  <input type="submit" value="submit">
                <form>
        
         </div>
       </div>
      ';
  ?>

  </div>
  </div>
  </center>

</body>
<?php
$name = $price = '';
if (isset($_POST['productid'])) {
    $productid=$_POST['productid'];
    
    $newprice=$_POST['newprice'];
    $addquery = "UPDATE `items` SET`price`=$newprice WHERE `id`=$productid"; 
    $res = mysqli_query($con, $addquery) or die(mysqli_error($con));
    echo "<div><center>Updated. <h3><a href='adminpanel.php'>Click to continue</a></h3></center></div>";
  }

?>