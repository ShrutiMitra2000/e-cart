<?php
$con=new mysqli("localhost","root","","e-cart");
if($con->connect_error)
{
    die("Connection failed");
}
function sanitize($string)
{global $con;
    $string= strip_tags($string);
    $string=htmlentities($string);
    $string=stripslashes($string);
    return $con->real_escape_string($string);

}
?>
