
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="adminstyle.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
   <style>
    #ques {
        height: 433px;
    }
    </style>
    <title>Admin Panel</title>
</head>


<body>
  <?php
  $prodid = $_GET['prodid'];
  require_once 'common.php';
  $sql = "SELECT * FROM `items` WHERE `id`=$prodid";
  $result = $con->query($sql);
  while ($row = $result->fetch_assoc()) {
    $id = $row['id'];
    $name = $row['name'];
    $price = $row['price'];
    $img = $row['image'];
  }
  require_once 'adminnav.php';
  ?>
<?php
 
  echo
  '<div class="container">
  <form action="deleteitem.php?prodid='.$prodid.'" method="post">
  <h2>Are you sure you want to delete this item?</h2>
  <input type="hidden" id="productid" name="productid" value="'.$prodid.'">
  <div class="form-check">
  <label class="form-check-label">
    <input type="radio" class="form-check-input" name="confirm" value="yes">Yes
  </label>
</div>
<div class="form-check">
  <label class="form-check-label">
    <input type="radio" class="form-check-input" name="confirm" value="no">No
  </label>
</div>
<input type="submit" value="submit">
</form>
</div>';
 ?>
  

</body>
<?php
$confirm='';
if (isset($_POST['productid'])) {
    $productid=$_POST['productid'];
    
    $confirm=$_POST['confirm']; 
    $deletequery = "Delete FROM `items`  WHERE `id`=$productid"; 
    $res = mysqli_query($con, $deletequery) or die(mysqli_error($con));
    echo "<div><center>deleted <h3><a href='adminpanel.php'>Click to continue</a></h3></center></div>";
  }
  $id= $name = $price = $img = '';
  ?>