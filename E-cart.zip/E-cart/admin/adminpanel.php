<?php
/*if(!isset($_SESSION['sno']))
echo "login first";
echo $_SESSION['login-email'];*/
?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
   <style>
    #ques {
        height: 433px;
    }
    </style>
    <title>Admin Panel</title>
</head>

<body>
    <?php
    require_once 'adminnav.php';
    require_once 'common.php';
         ?>
    <div class="container-fluid" id="ques">
              <h1 class="text-center">Welcome to admin panel!</h1>
              <div class="row my-2">
              <?php
              $sql="SELECT * FROM items";
              $result=$con->query($sql);
              while($row=$result->fetch_assoc())
              {$id=$row['id'];
                
                $name=$row['name'];
                $price=$row['price'];
                $img=$row['image'];
                
  echo '<div class="col-md-4 my-2">
    <div class="card">
      <div class="card-body" style="height:300px;">
            <img class="d-block w-100" src="/e-cart/'.$img.'" height="150px" width="180px">
        <h5 class="card-title"><a href="modify.php?prodid='.$id.'">'.$name.'</a></h5>
        <h6>&#x20B9;'.$price.'</h6>
        
        <a href="modify.php?prodid='.$id.'"class="btn btn-primary">Modify Price</a>
        <a href="deleteitem.php?prodid='.$id.'"class="btn btn-primary">Delete Item</a>
       </div>
     </div>
    </div>';}
    ?>
    </div>
    </div>
    
    <?php
    require_once 'adminfooter.php';
              
    ?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    
</body>
</html> 