
<head>
	<title>modification</title>
    <link rel="icon" href="../images/teacher.png" type="image/icon type">
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
	<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
	<!------ Include the above in your HEAD tag ---------->
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">
	<link rel="stylesheet" href="adminstyle.css">	
</head>

<body class="home">
    <div class="container-fluid display-table">
        <div class="row display-table-row">
            <div class="col-md-2 col-sm-1 hidden-xs display-table-cell v-align box" id="navigation">
                <div class="logo">
                   <a  class="logo" href="adminpanel.php"><span style="color: red">Admin</span></a>
                </div>
                <div class="navi">
                    <ul>
                        <li class="active"><a href="adminpanel.php"><i class="fa fa-home" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Home</span></a></li>                
                        <li><a href="productlistmod.php"><i class="fa fa-cog" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Product List modification</span></a></li>
                        <li><a href="logout.php"><i class="fa fa-log" aria-hidden="true"></i><span class="hidden-xs hidden-sm">logout</span></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-10 col-sm-11 display-table-cell v-align">
            
                <div class="user-dashboard text-info">
                    <h1>Product List</h1>
            <div class="container">
<?php
session_start();
session_destroy();
require 'includes/common.php';
$sql = "SELECT * FROM items";
$result = $con->query($sql);
?>
              <div class='top-bar'>
                <ul>
                <li><a href='additem.php'>Add item</a></li>
                <li><a href='deleteitem.php'>Delete item</a></li>
                </ul>
              </div>

            </div>
            </div>

</div>
</div>


</body>