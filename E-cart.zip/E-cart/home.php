<?php
require 'includes/common.php';

?>
<!DOCTYPE html>
<html>
    <head>
        <title>E-CART</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
              <script src="bootstrap/js/jquery-3.5.1.min.js"></script>
              
        <!-- Latest compiled and minified JavaScript -->
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="style.css">
        <style>

.round {
  border-radius: 50%;
}
.previous {
  background-color: #f1f1f1;
  color: black;
}

.next {
  background-color: #222;
  color: white;
}
        </style>
    </head>
    <body>
      <?php    include_once 'includes/header.php';
              require_once 'includes/if-added.php';
              ;?>  
       <div class="container-fluid" style="margin-top: 90px; margin-bottom: 50px;">
             
              <div class="row my-2">
              <?php
              $sql="SELECT * FROM items";
              $result=$con->query($sql);
              while($row=$result->fetch_assoc())
              {$id=$row['id'];
                
                $name=$row['name'];
                $price=$row['price'];
                $img=$row['image'];
                echo '<div class="col-md-4 my-2">
                <div class="thumbnail">
                <img src="'.$img.'" height="250px" width="280px">
                <div class="caption">
                <h4 class="card-title">'.$name.'</h4>
                <h4><b>Price:&#x20B9; '.$price.'</b></h4>';
                if(!isset($_SESSION['email']))
                        {
                        echo '<button class="btn btn-primary btn-block ml-3"  data-toggle="modal" data-target="#loginmodal">Buy Now</button>';
                        }
               else{
                      if (check_if_added_to_cart(1)) {
                             echo '<a href="#"><button type="button" class="btn btn-primary btn-block" disabled >Added to cart</button></a>';
                      }else{
                         echo' <a href="cart-add.php?id=1"><button type="button" class="btn btn-primary btn-block" >Add to cart</button></a>';
                      }
                    }
                        
                echo '</div>
                </div>
    </div>';}
    ?>
    </div>
    </div>
      <?php
      require_once 'includes/footer.php';
      ?>              
</body>
</html>
