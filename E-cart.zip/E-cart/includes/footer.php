<head>
    <style>
        th,td{
            padding-left: 20px;
           padding-right:250px;
           padding-bottom:2px;
           color: #989898;
        }
        td{
            padding-bottom:1px;
        }
    </style>
</head>
<footer style="bottom:0;right:0;left:0;">
<div class="container-fluid">
        <table class="class">
        <tbody>
        <th>Information</th>
        <th>My&nbsp;Account</th>
        <th>Contact Us</th>
        <tr><td><a href="about.php" style="color: whitesmoke">About Us</a></td>
            <td><a href="#"  data-toggle="modal" style=" color: whitesmoke" data-target="#loginmodal">Login</a></td>
            <td style="color: whitesmoke">Contact: +91-123-000000</td></tr>
        <tr><td><a href="contact.php" style="color: whitesmoke">Contact Us</a></td>
            <td><a href="sign up.php" style="color: whitesmoke">Signup</a></td><td></td></tr>
        </tbody>
    </table>
</div>
</footer>
