<?php
$con= mysqli_connect("localhost", "root", "", "e-cart")or die(mysqli_error($con));
session_start();
?>
