<html>
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="adminstyle.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
   <style>
    #ques {
        height: 433px;
    }
    </style>
    <title>Admin Panel</title>
</head>


<body>
  <?php
    require_once 'includes/common.php';
    require_once 'admin/common.php';
   require_once 'admin/adminnav.php';
  ?>
<div class="container">
  <form action="additem.php" method="POST" name="myForm" onsubmit="return validateForm()" enctype="multipart/form-data">
  <h2>Add item</h2>
  <div class="input-group form-group" id="name">
  <input type="text" placeholder=" Name of product"  name="name" class="add" id="name" ><br>
  <b><span class="formerror"></span></b>
  </div>
  <div class="input-group form-group" id="price">
  <input type="text" placeholder=" Price of product"  name="price" class="add" id="price" required><br>
  <b><span class="formerror"></span></b>
  </div>
  <div class="input-group form-group" id="image">
  <input type="file" id="img" name="image" accept="image/*" required><br>
  <b><span class="formerror"></span></b>
  </div>
<input type="submit" value="submit" id="submit">
</form>
</div>

  

</body>
<script>
  function clearErrors(){
errors = document.getElementsByClassName('formerror');
for(let item of errors)
{
    item.innerHTML = "";
}
  }

function seterror(id, error){
//sets error inside tag of id 
element = document.getElementById(id);
element.getElementsByClassName('formerror')[0].innerHTML = error;

}
function validateForm(){
var returnval = true;
clearErrors();
var name = document.forms['myForm']["name"].value;
if (name.length == 0){
   seterror("name", " *Length of name cannot be zero!");
    returnval = false;
}


var price = document.forms['myForm']["price"].value;
if (isNaN(price)){
    seterror("price", " *price should be number");
    returnval = false;
}
return returnval;
  }


</script>
</body>
<?php
if(isset($_POST['name']))
{
$name=$_POST['name'];
$name = sanitize($name);
echo $name;
$price=$_POST['price'];
$price=sanitize($price);
echo $price;
$select="SELECT * FROM items where name='$name'";
$result = mysqli_query($con, $select)or die(mysqli_error($con));
$num = mysqli_num_rows($result);

if($num!=0)
{
    echo "item already exist";
}
if(isset($_FILES['image'])){
  $errors= array();
  $file_name = $_FILES['image']['name'];
  $file_size =$_FILES['image']['size'];
  $file_tmp =$_FILES['image']['tmp_name'];
  $file_type=$_FILES['image']['type'];
  $file_ext=explode('.', $file_name);
  $filecheck=strtolower(end($file_ext));
  $destination="img/".$file_name;
      
  if(empty($errors)==true){
     move_uploaded_file($file_tmp,"img/".$file_name);
     //if(rename("img/".$file_name,'/e-cart/img/'.$file_name))
    { echo "Success";}
  }else{
     print_r($errors);
  }
}
echo $destination;
$addquery="INSERT INTO items(name, price,image)VALUES('" . $name . "','" . $price . "','".$destination."')";
$res = mysqli_query($con, $addquery) or die(mysqli_error($con));

echo "<div class='impmsg' style='background-color: whitesmoke;color:black;font-size:20px;text-align:center'>$name is added. <a href='admin/adminpanel.php'>Click to continue</a></div>";


}
?>
</html>