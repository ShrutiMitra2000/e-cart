
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
              <script src="bootstrap/js/jquery-3.5.1.min.js"></script>
              
        <!-- Latest compiled and minified JavaScript -->
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="style.css">
<style>
body {
  font-family: Arial;
  font-size: 17px;
  padding: 8px;
}

* {
  box-sizing: border-box;
}
            img
            {
                height: 100px;
                width: 150px;
            }
.formstyle{
    background-color: white;
    width:600px;
    padding:5px;
    border:0.5px solid blanchedalmond;

}
form{display: table;
     }
label{
    margin:5px;
    display:table-row;
}
input{
    margin:5px;
    display: table-row-group;
}
.btn1{
    margin-right: 5px;
}

</style>
</head>
<body>

<?php        require 'includes/header.php';
             require_once 'includes/common.php';
                           $user_id = $_SESSION['id'];
                  $select_query = "SELECT ui.id,ui.item_id,i.name,i.price,i.image FROM users_items ui INNER JOIN items i ON i.id = ui.item_id WHERE user_id = '$user_id' AND status = 'Added to cart'";
                  $result = mysqli_query($con, $select_query);
                  $sum=0;
                  $i=0;
                  $sel="SELECT * from users where id='$user_id'";
                  $res = mysqli_query($con, $sel);
                  while ($row = mysqli_fetch_assoc($res))
                  {
                  $user_email=$row['email'];
                  $address=$row['adress'];}
                  echo ';<div class="container head">
                  <div class="col">
                  
                      <h3>Confirm Order('.mysqli_num_rows($result).')</h3>
                      <hr>';
                           
                        if (mysqli_num_rows($result)==0) {
                            echo "Add item to cart first!";
                        }
                        else
                        {   
                           $sum=0;
                           
                            while ($row=mysqli_fetch_array($result))
                            {
                                $i++;
                                $sum += $row['price'];
                                $id = $row['item_id'].',';
                                
                              
                                $_SESSION['item_id'] = $row['item_id'];
                      echo '<div class="row">
                      <div class="col-md-3">
                          <img src="'.$row['image'].'">
                      </div> 
                      <div class="col-md-8  xmp">
                          <h4>'.$row['name'].'</h4>
                          <h4><b>Price: Rs '.$row['price'].'</b></h4>
                          
                      </div>
                      </div>';
                            }
                        }
                echo' <div class="col">
                        <h3 style="color: #878787;">PRICE DETAIL</h3>
                        <hr>
                        <h4>Price('.$i.')  Rs - '.$sum.'</h4>';
                        if (mysqli_num_rows($result)==0) {
                              echo '<h4>Delivery Fee Rs.0</h4>';
                          }
         else {
                          echo '<h4>Delivery Fee  Rs - 540</h4>
                          
                        <hr>';
                          $sum = $sum+540;
                          echo '<h3>TOTAL Rs - '.$sum.'</h3>
                          </div>';
         }
                        
                        echo ' <div > 
                        <center>
                         <form  action="payment.php" method="post" class="formstyle">
                            <h3 style="margin:20px 10px;font-family: lato;">Checkout Form</h3>             
                            <label for="fname"><i class="fa fa-user"></i> Full Name</label>
                            <input type="text" id="fname" name="name" placeholder="John M. Doe" required><br>
                            <label for="email"><i class="fa fa-envelope"></i> Email</label>
                            <input type="text" id="email" name="email" placeholder="Email" required><br>
                            <input type="hidden" value="'.rand(100,1000).'" name="orderid">
                            <input type="hidden" value="'.$sum.'" name="amount"required>
                            <label for="city"><i class="fa fa-mobile"></i> Mobile</label>
                            <input type="text" id="city" name="mobile" placeholder="Mobile Number" required><br>
                            <label for="adr"><i class="fa fa-address-card-o"></i> Address</label>
                            <input type="text" id="adr" name="address" placeholder="'.$address.'"required>
                            <br>                     
                       
                        <input type="submit"  value="Pay Now" class="btn btn-primary btn-block btn1">
                      </form>
                      </center>';
                        
                    echo '</div>
                    </div>
                    
                </div>';
                      
?>

  
  </div>
